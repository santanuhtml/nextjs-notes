function Footer(){
  return(
    <div>
      <footer>
        <div className="container">
          <div className="row">
            <div className="col-md-12 text-center">
              <p> Copyright 2022</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
export default Footer;